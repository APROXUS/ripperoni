﻿using System;
using System.IO;
using System.Windows;
using System.Windows.Controls;

namespace Ripper.MVVM.View
{
    /// <summary>
    /// Interaction logic for AboutView.xaml
    /// </summary>
    public partial class AboutView : UserControl
    {
        public AboutView()
        {
            InitializeComponent();
        }
    }
}

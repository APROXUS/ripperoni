﻿using System.Windows.Controls;

namespace Ripper.MVVM.View
{
    /// <summary>
    /// Interaction logic for PropertiesView.xaml
    /// </summary>
    public partial class PropertiesView : UserControl
    {
        public PropertiesView()
        {
            InitializeComponent();
        }
    }
}

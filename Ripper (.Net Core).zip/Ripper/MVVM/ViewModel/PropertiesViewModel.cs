﻿namespace Ripper.MVVM.ViewModel
{
    class PropertiesViewModel
    {

    }
}

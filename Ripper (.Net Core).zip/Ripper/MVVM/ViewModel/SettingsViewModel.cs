﻿namespace Ripper.MVVM.ViewModel
{
    class SettingsViewModel
    {

    }
}

﻿namespace Ripper.MVVM.ViewModel
{
    class AboutViewModel
    {

    }
}

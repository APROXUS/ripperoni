﻿namespace Ripper.MVVM.ViewModel
{
    class DownloadsViewModel
    {

    }
}
